package cn.yfwl.dygy;

import android.app.Application;

import cn.jpush.android.api.JPushInterface;

/**
 * Created by Administrator on 2017/12/11.
 * 创建人 ： Administrator
 * 功能描述 ：
 * 创建时间 ：2017/12/11
 */

public class MainApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        JPushInterface.setDebugMode(true);
        JPushInterface.init(this);
    }
}
